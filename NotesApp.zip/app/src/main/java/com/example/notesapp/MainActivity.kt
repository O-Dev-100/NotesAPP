package com.example.notesapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    private lateinit var notesAdapter: NotesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        val addNoteButton: FloatingActionButton = findViewById(R.id.addNoteButton)

        notesAdapter = NotesAdapter(mutableListOf())
        recyclerView.adapter = notesAdapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        addNoteButton.setOnClickListener {
            val dialog = NoteDialogFragment { noteText ->
                if (noteText.isNotEmpty()) {
                    notesAdapter.addNote(noteText)
                }
            }
            dialog.show(supportFragmentManager, "NoteDialogFragment")
        }
    }
}